/**
 * Utility classes used by Jackson Core functionality.
 */
package org.codehaus.jackson.util;
